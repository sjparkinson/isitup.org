﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

	<title>Your Website Title...</title>
	
	<!-- Version: 3.10, p.s. try and find the easter egg :P -->

	<link rel="icon" type="image/png" href="/icon.png" />
	<link rel="stylesheet" type="text/css" href="assets/stylesheets/compressed.css" />
	<meta name="description" content="" />
	<meta name="keywords" content="" />
	<script type="text/javascript">
	// <![CDATA[
	function clean(e) {
		var c = '#36393D';
		if (e.value == 'example.com') {
			e.value = '';
			e.style.color = c;
		} else {
			e.style.color = c;
		}
	}

	function check() {
		d = document.getElementById('input').value;
		d = d.replace(/http(s)?:\/\//,"");
		d = d.replace(/\/(.*)/g, "");
		window.location = '/check/' + d;
		return false;
	}
	
	function toggle() {
		var h = document.getElementById('help');
		h.style.display = (h.style.display != 'none' ? 'none' : '' );
	}
	// ]]>
	</script>
</head>
<body>
<div id="container">
	<noscript>
		<p class="warning">Please don't enter "http://" or a trailing slash, as you do not seem to be using javascript.<br />You'll also need to press "enter" to submit the form.</p>
	</noscript>

	<form method="get" action="check.php" onsubmit="return check();">
		<p>is&nbsp;<input type="text" name="domain" id="input" value="example.com" onclick="clean(this);" />&nbsp;<a href="javascript:check();">up?</a></p>
	</form>
	
	<p class="info" id="help" style="display:none;">This nifty tool checks if a given <b>domain</b> or <b>IP address</b> is up, or down.<br />So go ahead and type something in the box above and press enter, we'll then tell you if the site is working or take a guess at what's wrong.</p>
</div>

<div id="footer">
	<a href="javascript:toggle();">Confused?</a>
</div>

</body>
</html>