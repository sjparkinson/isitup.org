<?php

############# Configuration #############

error_reporting(0); // use "0" in production, and "E_ALL" for testing

ini_set('default_socket_timeout', 4); // set how long to check for, doesn't seem to work though...

#########################################


// retrieves the url to test, then cleans it up
$domain = preg_replace("/[^A-Za-z0-9-\/\.\:]/", "", trim($_GET["domain"]));

// if domain has a ":", breaks up the url given into domain & port, setting them to seperate variables
if (strpos($domain, ':') != false) {
	list ($domain, $port) = explode (":", $domain); // split the variable into two, $domain & $port
	
	if (!is_numeric($port)) { $port = 80; }; // if the port is not numeric we use port 80
};

// the timing function to see how long it takes to connect
function microtiming()
{
    list($usec, $sec) = explode(" ", microtime());
    return ((float)$usec + (float)$sec);
}

// the main function, checks the domain with curls response and returns a sutiable message and title
function check($link) {

	// get the global variables into this function
	global $domain, $port;		

	// reg expression used to check if the domain or ip address is valid
	$domexprcheck	= "/^([a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,6}$/i";
	$ipexpcheck		= "/^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/i";

	// check the domain is valid, continue if true, otherwise tell the user we need a proper domain
	if (preg_match($domexprcheck, $domain) == true || preg_match($ipexpcheck, $domain) == true) {

		$url = "http://" . $domain . ":" . $port; // merge the domain and port

		// start the timmer
		$time_start = microtiming();

			// retrieves just the http header response
			$headers = @get_headers($url);

		// stop the timmer
		$time_stop = microtiming();

		// caluate and format the time taken to connect
		$time = round($time_stop - $time_start, 3);

		// extract the response code
		preg_match("/[0-9]{3}/", $headers[0], $matches);

		@$code = $matches[0]; // get the first thing from the matches array, it should be the response code

		// sort out the timmers units
		if ($time == 1) { $units = "second"; } else { $units = "seconds"; };

		// preliminary response check
		if ($domain == 'isitup.org') {

			$message[0]  = "<script type=\"text/javascript\" src=\"../../assets/javascript/flip.js\"></script>\n\n";
			$message[0] .= "\t<p><a href=\"../../\" class=\"u\">try again</a></p>\n\n";
			$message[0] .= "\t<p class=\"u\">now look what you've done!</p>\n";

			// page title
			$message[1]  = "You what?";

		// for a normal response let the user know the site is up
		} else if ($code == 200 || $code == 301 || $code == 302 || $code == 303 || $code == 304 || $code == 307) {

			$message[0]  = "<p><a href=\"http://" . $domain . "\" class=\"domain\">" . $domain . "</a> replied to our message, i.e. it's working :)</p>\n\n";
			$message[0] .= "\t<p class=\"smaller\">It took them " . $time . " " . $units . " to reply, we also got a " . $code . " <a href=\"http://en.wikipedia.org/wiki/List_of_HTTP_status_codes\">http status code</a>.</p>\n\n";
			$message[0] .= "\t<p class=\"smaller\"><a href=\"../../\">Check another site?</a></p>\n";

			// page title, if normal
			$message[1]  = "Yep, " . $domain . " is up.";

		// the site requires auth. so let the user know
		} else if ($code == 401) {
			$message[0]  = "<p><a href=\"http://" . $domain . "\" class=\"domain\">" . $domain . "</a> replied to our message, i.e. it's working :)</p>\n\n";
			$message[0] .= "\t<p class=\"smaller\">It took them " . $time . " " . $units . " to reply, we also got a " . $code . " <a href=\"http://en.wikipedia.org/wiki/List_of_HTTP_status_codes\">http status code</a>, which means you need to login.</p>\n\n";
			$message[0] .= "\t<p class=\"smaller\"><a href=\"../../\">Check another site?</a></p>\n";

			// page title, if auth. required
			$message[1]  = "Yep, " . $domain . " is up, but...";

		// for all other responses say the site might be down
		} else {

			// if we got a http response code, but it isn't one that we like
			if ( isset($code) ) {
				$text = "We got a " . $code . " <a href=\"http://en.wikipedia.org/wiki/List_of_HTTP_status_codes\">http status code</a> from them.";

			// if we don't get a http response code (e.g. the server is totally down...)
			} else {
				$text = "Check that you typed in the right domain though.";
			};

			$message[0]  = "<p>We think you're onto something. <a href=\"http://" . $domain . "\" class=\"domain\">" . $domain . "</a> seems to be down :(</p>\n\n";
			$message[0] .= "\t<p class=\"smaller\">" . $text . " <a href=\"../../\">Check another site?</a></p>\n";

			// page title, if timeout
			$message[1]  = "Oh noes! " . $domain . " is down.";

		};

	// for an invalid domain
	} else {
	
		$message[0]  = "<p>We need a valid domain to check! <a href=\"../../\">Try again.</a></p>\n";
	
		// page title, if invalid domain
		$message[1]  = "Woops...";
	
	};

// return the page title and message as an array
return $message;

};