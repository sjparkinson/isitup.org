<?php include('functions.php'); $message = check($domain); // include functions, then check the site and get the messages ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8"/>

	<title><?php echo $message[1]; // display the dynamic title ?></title>

	<link rel="icon" type="image/png" href="../icon.png" />
	<link href="../../assets/stylesheets/compressed.css" rel="stylesheet" type="text/css" />
	<meta name="description" content="The availability results for <?php echo $domain; ?>." />
	<meta name="keywords" content="" />
	<script src="/mint/?js" type="text/javascript"></script>
</head>
<body>
<div id="container">
	<?php echo $message[0]; // displays the response for the site we're checking ?>
</div>

</body>
</html>